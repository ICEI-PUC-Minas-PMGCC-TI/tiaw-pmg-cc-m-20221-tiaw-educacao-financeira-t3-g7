const dados_Cards = {
    "temas": [
        {
            "id": "tema1",
            "imagem": "imagens/bitcoin.webp",
            "titulo": "CRIPTOMOEDAS",
            "descricao": "Nesta sessão abordaremos os tópicos mais importantes a respeito das diferentes criptomoedas existentes e do mercado financeiro que as envolve.",
            "titulo2": "O que são as criptomoedas?",
            "subtitulo1": "Como contextualização, tem-se que a criptomoeda tem esse nome porque usa o recurso de criptografia para verificar as transações. Isso significa que uma codificação avançada está envolvida no armazenamento e na transmissão de dados de criptomoeda entre as carteiras e os livros contábeis públicos. O objetivo da criptografia é oferecer segurança e proteção.",
            "p1": "Criptomoeda é um sistema de pagamento digital que não depende de bancos para verificar e confirmar transações. É um sistema ponto a ponto que permite a qualquer pessoa enviar e receber pagamentos de qualquer lugar. Em vez do dinheiro físico transportado e trocado no mundo real, os pagamentos em criptomoeda existem unicamente como valores digitais em um banco de dados online que documenta as transações específicas. Ao transferir fundos de criptomoeda, as transações são registradas em um livro contábil público. A criptomoeda é armazenada em carteiras digitais. A primeira criptomoeda foi o Bitcoin,criada em 2009 e ainda hoje a mais conhecida.",
            "titulo3": "Como a criptomoeda funciona?",
            "subtitulo2": "As criptomoedas são executadas em um livro público distribuído chamado blockchain, um registro de todas as transações atualizadas e mantidas pelos detentores das moedas.",
            "p2": "Unidades de criptomoedas são criadas por meio de um processo chamado mineração, que envolve o uso de potência de computação para resolver problemas matemáticos complicados que geram moedas. Os usuários também podem comprar moedas com as corretoras, depois armazená-las e gastá-las usando carteiras criptográficas. Se você possui criptomoeda, não possui nada físico, mas uma chave que permite mover um registro ou uma unidade de medida de uma pessoa para outra, sem necessidade de uma terceiro confiável.",
            "titulo4": "Como investir em criptomoedas",
            "subtitulo3": "Existem algumas formas de investir ou adquirir Bitcoins e outras criptomoedas.",
            "p3": "É possível comprar cotas de fundos de criptomoedas, negociá-las diretamente em uma corretora especializada (também conhecida como exchange), aceitando as moedas digitais como pagamento em algum negócio ou ainda minerando. Adquirir cotas de fundos é uma das formas mais simples. Em 2018, a Comissão de Valores Mobiliários (CVM) permitiu que os fundos brasileiros fizessem investimentos indiretos em criptomoedas no exterior – comprando derivativos ou cotas de outros fundos, por exemplo. Essas carteiras são distribuídas por corretoras e plataformas de investimento e alguns demandam aplicações de valor relativamente baixo (de R$ 5.000 ou até menos). Os fundos podem ser uma boa alternativa para quem quer se expor ao mercado de criptomoedas, mas não se sente seguro para fazer isso sozinho, já que quem decide e acompanha as aplicações é um gestor especializado.",
            "titulo5": "Vantagens e riscos de investir em criptomoedas",
            "subtitulo4": "Criptomoedas são ativos recentes e com uma lógica bastante sofisticada de funcionamento. Por isso, ainda há muita gente procurando entender melhor como operar com elas.",
            "p4": "As moedas digitais têm algumas vantagens sobre moedas físicas e outros meios de pagamentos. O site Bitcoin.org lista as seguintes para os Bitcoins: LIBERDADE DE PAGAMENTO; TAXAS BAIXAS; SEGURANÇA; TRANSPARENCIA; MAIOR GRAU DE ACEITAÇÃO; VOLATILIDADE",
        },

        {
            "id": "tema2",
            "imagem": "imagens/pilares.jpg",
            "titulo": "PILARES DA EDUCAÇÃO FINANCEIRA",
            "descricao": "Nesta sessão abordaremos os principais pilares da educação financeira, a ponto de esclarecer as melhores maneiras de fazer uso consciente do seu próprio dinheiro.",
            "titulo2": "Primeiro pilar: Entendimento de seu dinheiro e seus hábitos",
            "subtitulo1": "Este primeiro pilar é quase um exercício para se conhecer e conhecer quem vive com voçê e divide sonhos, objetivos e contas.",
            "p1": "O primeiro passo para saber como estão suas finanças é fazer um diagnóstico da sua situação financeira. O orçamento pessoal ou familiar deve ser organizado em forma de planilha financeira, reunindo a maior quantidade possível de informações. Todo tipo de renda, sendo salários, rendimentos de investimentos ou mesmo pagamentos por serviços esporádicos precisam entrar na planilha. Além da renda, todos os gastos também devem ser anotados na planilha. Assim você passa a conhecer seus hábitos e os hábitos dos seus familiares com relação ao dinheiro. É importante deixar claro que tal tipo de organização pode ser feita em qualquer tipo de planilha financeira, seja de papel ou eletrônica.",
            "titulo3": "Segundo pilar: Definição do que fazer com o dinheiro",
            "subtitulo2": "Depois de conhecer os hábitos com o dinheiro, o segundo pilar da educação financeira é definir objetivos. Afinal, aonde você quer chegar? O que gostaria de realizar? O que te faria muito feliz no futuro?",
            "p2": "Ganhando muito ou pouco, é necessário ter a noção de que há um limite mensal de dinheiro com que você pode contar. Definir objetivos a partir desse limite permite focar nas prioridades da sua vida. Esses objetivos podem ser de curto prazo, como uma viagem, ou até algo mais longo, como se aposentar",
            "titulo4": "Terceiro pilar: Revisar",
            "subtitulo3": "Agora, munido de informação precisa sobre o estado da sua vida financeira, o próximo passo consiste em analisar essa informação e revisar quais são os comportamentos problemáticos em sua vida financeira.",
            "p3": "Assim, você pode definir o que precisa ser alterado para alcançar seus objetivos financeiros, bem como o que é positivo e deve ser reforçado.",
            "titulo5": "Quarto pilar: Realizar",
            "subtitulo4": "Para fechar com chave de ouro, o último dos 4 pilares é o da realização. Nessa altura do campeonato, você deve estar com a faca e o queijo na mão: sabendo qual o balanço no final de cada mês, quais gastos podem e devem ser cortados, quais investimentos seriam benéficos e quais objetivos você deseja alcançar.",
            "p4": "Sendo assim, o último passo é bastante simples, desde que os anteriores tenham sido realizados de maneira adequada. Basta de fato fazer os cortes necessários, alocar os recursos de maneira consciente e racional e investir seu capital de maneira estratégica e calculada.",
        },

        {
            "id": "tema3",
            "imagem": "imagens/imposto.jpeg",
            "titulo": "IMPOSTOS",
            "descricao": "Aqui abordaremos tudo o que você precisa saber sobre os principais impostos.",
            "titulo2": "O que é Imposto?",
            "subtitulo1": "Como o próprio nome já indica, é algo que é obrigado.",
            "p1": "O Imposto é um tributo obrigatório cobrado pelo governo. Isso quer dizer que é um valor que você paga e contribui para custear as despesas administrativas do Estado. O não pagamento pode gerar multas e até punição legal. Ao olhar por esse lado até parece algo ruim. Mas se você pensar, sem a cobrança de impostos nenhum país no mundo conseguiria devolver serviços e benefícios para população. É como se você estivesse investindo no governo para que ele possa cuidar dos seus serviços básicos, como saúde, educação, segurança e etc.",
            "titulo3": "Imposotos Federais",
            "subtitulo2": "Impostos federais são responsáveis por cerca de 60% (sessenta por cento) do total das arrecadações de impostos no país, sendo os que existem em maior quantidade e também são os mais reconhecidos por suas siglas. Em geral seu destino é a manutenção do Governo Federal. ",
            "p2": "Dentre os principais: II: Imposto sobre importação, para mercadorias vindas de fora do país; IOF: Imposto sobre operações financeiras, para empréstimos, ações e demais ações financeiras; IPI: Imposto sobre produtos industrializados, para a indústria; IRPF: Imposto de Renda Pessoa Física, sobre a renda do cidadão; IRPJ: Imposto de Renda Pessoa Jurídica, sobre a renda de CNPJs; Cofins: Contribuição de financiamento da seguridade social; INSS: Instituto Nacional do Seguro Social",
            "titulo4": "Imposotos Estaduais",
            "subtitulo3": "Já os impostos estaduais são destinados a manutenção da administração do Governo Estadual, bem como a financiamento de serviços públicos do estado e investimentos em infraestrutura a nível estadual (escolas e faculdades estaduais, rodovias estaduais, etc). São responsáveis por cerca de 28% (vinte e oito por cento) da arrecadação total",
            "p3": "São eles: ICMS:  Impostos sobre circulação de mercadorias e serviços; IPVA: Imposto sobre a propriedade de motores automotores; ITCMD: Imposto de transmissão causa mortis e doação",
            "titulo5": "Imposotos Municipais",
            "subtitulo4": "Os impostos municipais são de ordem do município e destinados a manutenção da administração pública local, serviços, investimentos e manutenções locais. São destinados para escolas municipais, unidades de pronto atendimento, etc. São responsáveis por cerca de 5,5% (cinco e meio por cento) da arrecadação total do país.",
            "p4": "São eles: IPTU: Imposto sobre propriedade territorial urbana; ISS: Imposto sobre serviços; ITBI: Imposto de transmissão de bens imóveis",
        },

        {
            "id": "tema4",
            "imagem": "imagens/investimento.jpeg",
            "titulo": "MODALIDADES DE INVESTIMENTOS",
            "descricao": "Aqui será abordado as principais informações sobre investimentos que você precisa saber.",
            "titulo2": "O Que São Investimentos Financeiros?",
            "subtitulo1": "Os investimentos podem ser interpretados como produtos para fazer o seu dinheiro render e ainda auxiliar no desenvolvimento de setores da economia ou empresas.",
            "p1": "Os investimentos são produtos emitidos pelas instituições financeiras, empresas ou pelo próprio governo com o objetivo de captar recursos de forma mais barata que os empréstimos bancários. Em troca, eles oferecem uma taxa de rentabilidade ou benefícios, como se tornar sócio do negócio e recebimento de proventos.",
            "titulo3": "Quais São Os Tipos de Investimentos Disponíveis no Mercado ",
            "subtitulo2": "Os investimentos são classificados, majoritariamente, em renda fixa ou variável. Esta nomenclatura vem da forma de rentabilidade que eles podem oferecer.",
            "p2": "A renda fixa é conhecida por oferecer taxa de rentabilidade estável e baixo risco. No momento da compra, você já tem ideia de quanto o seu dinheiro vai render até a data do vencimento. O funcionamento consiste em um empréstimo do capital ao emissor, por exemplo, o governo, bancos ou financeiras. Já os investimentos da renda variável possuem retornos oscilatórios, ou seja, em um mês você pode ganhar 5% e no outro perder 10%. Eles normalmente são considerado mais arriscados, no entanto, é importante destacar que renda variável também pode ser interessante para perfis conservadores, quando analisada com cuidado. Ao optar por investimentos da renda variável, você pode comprar uma parte de um negócio, como empresas, imóveis ou commodities. Neste caso, o retorno vem da valorização destas frações, isto é, das suas cotações na bolsa de valores. Assim, não há como saber quanto você vai ganhar no futuro.",
            "titulo4": "Qual o Melhor Tipo de Investimento para Iniciantes?",
            "subtitulo3": "Uma das dúvidas mais comuns para quem está começando é definir onde alocar o capital. Afinal de contas, há diversos investimentos, cada um deles com características distintas. Se este também é o seu questionamento, a dica é: inicie devagar e conheça o mercado.",
            "p3": " Então, os investimentos que costumam ser indicados são os de renda fixa, pois eles possuem taxas de rendimento mais estáveis e baixo risco. O seu dinheiro poderá render sem comprometer o montante inicialmente aplicado. Apesar de que boa parte dos investimentos de renda fixa possuem custos, como o Imposto de Renda e IOF, eles incidem apenas sobre o rendimento. Entre os ativos mais indicados, temos o Tesouro Direto, os CDBs, LCI e LCA. Estes últimos são isentos de taxas. Logo, podem ser boas alternativas para o seu patrimônio. Vale lembrar que há investimentos que possuem liquidez diária, como é o caso do títulos públicos e de alguns CDBs. Por isso, é necessário conhecer cada um deles a fundo e escolher a melhor opção segundo os seus objetivos como investidor. Por outro lado, existem grandes expectativas para ativos de renda variável esse ano e é possível encontrar títulos híbridos, que diminuem o risco. Fundo de investimento imobiliário são um bom exemplos de boa oportunidade",
            "titulo5": "Como e Por Onde Começar a Investir?",
            "subtitulo4": "Começar a investir é um marco na vida de qualquer pessoa. Neste momento, você deixa de apenas poupar para ver o seu dinheiro crescer. ",
            "p4": "Se você quer dar este novo passo e atingir os seus objetivos, a primeira coisa a ser feita é obter conhecimento. Tenha em mente que quanto mais informações você tiver, a tendência é de que as suas decisões sejam cada vez melhores. Depois de obter conhecimento, basta procurar uma corretora de valores. Priorize sempre aquelas de confiança e que possuem anos de mercado",
        },

        {
            "id": "tema5",
            "imagem": "imagens/planejamento_financeiro.jpg",
            "titulo": "PLANEJAMENTO FINANCEIRO",
            "descricao": "O planejamento financeiro é o processo de atingir as metas financeiras da vida por meio do gerenciamento adequado dos recursos financeiros.",
            "titulo2": "Por que você precisa de um Planejamento Financeiro?",
            "subtitulo1": "O Comitê de Padrões de Planejamento Financeiro Ltd. (FPSB) define planejamento financeiro como um “processo de desenvolvimento de estratégias para ajudar as pessoas a administrar seus assuntos financeiros para atingir os objetivos de sua vida”. ",
            "p1": "O planejamento financeiro elimina as suposições sobre o gerenciamento de suas finanças e ajuda a entender as implicações de cada decisão financeira que você toma. Todo mundo tem objetivos diferentes, por isso é importante ter um plano que funcione para você e sua situação financeira, agora e no futuro.",
            "titulo3": "Quais os benefícios do Planejamento Financeiro?",
            "subtitulo2": "O planejamento financeiro possui diversos benefícios para a nossa vida. Dentre eles são:",
            "p2": "Proporciona uma vida mais equilibrada; Ajuda a conquistar seus sonhos e objetivos; Não te deixa ter aquela dúvida sobre para onde o dinheiro foi no fim do mês; Ajuda a cortar gastos desnecessários; Evita juros e dívidas; Consegue se programar para poupar; Tem menos estresse;",
            "titulo4": "Como um sistema de gestão ajuda no planejamento financeiro de seu negócio? ",
            "subtitulo3": "Você percebeu que muitas das tarefas que um planejamento financeiro exige, desde sua concepção até a implementação, são complexas, certo? São atividades que exigem análise, curadoria de dados e monitoramentos constantes.",
            "p3": "Já pensou o quão difícil isso pode ser, caso feito à mão em sua empresa, com dedicação de um, dois ou mesmo um time inteiro de profissionais? É um dos motivos pelos quais muitas empresas falham em criar seu planejamento financeiro. O sistema de gestão ajuda justamente nesse ponto, encarregando-se de ser tanto o cérebro como os braços que agem em cima do seu planejamento. Essa solução oferece as ferramentas necessárias para você organizar cada aspecto do seu negócio, em especial suas finanças. Assim, você organiza dados e informações sobre o negócio e torna mais fácil a visualização do(s) orçamento(s), do faturamento, das vendas e do estoque, e de todo fluxo de caixa.",
            "titulo5": "Monitore seu controle financeiro e investimentos ",
            "subtitulo4": "Nessa sua jornada em busca de uma aposentadoria tranquila e uma renda fixa de olho no olho prazo, é importante manter um controle financeiro e dos investimentos.",
            "p4": "Isso significa acompanhar mensalmente como os números estão se virando e o que você deve adaptar para se manter no rumo certo. Assim, é importante ficar de olho no noticiário econômico. Como está o humor do mercado? Quais são as perspectivas para a Selic? E para a inflação? Todos esses elementos citados são importantes para você compor (e recompor) sua carteira de investimentos. Na esfera pessoal, também é essencial manter o controle dos gastos e dos rendimentos. Como está aquele corte de custos imposto no início? Ele se manteve? Houve imprevistos no caminho? Então, é hora de ajustar a planilha.",
        },

    ]
}

const init = (data) => {
    
    localStorage.setItem('db_temas', JSON.stringify(dados_Cards))

    let dadosHTML = '';
    for (let i = 0; i < dados_Cards.temas.length; i++) {
        let tema = dados_Cards.temas[i];
        dadosHTML += `
        <div class="col-12 col-sm-12 col-md-6 col-lg-3">
                <div class="card" style="width: 18rem;">
                    <img src="${tema.imagem}" class="card-img-top" alt="criptomoeda">
                    <div class="card-body">
                      <h5 class="card-title">${tema.titulo}</h5>
                      <p class="card-text">${tema.descricao}</p>
                      <a href="detalhes_tema.html?id=${tema.id}" class="btn btn-primary">Conferir</a>
                    </div>
                </div>
        </div>
        `
    }
    document.getElementById ('divListaTemas').innerHTML = dadosHTML
}

document.body.onload = init;